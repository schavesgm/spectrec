# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spectrec',
 'spectrec.factory',
 'spectrec.factory.kernel',
 'spectrec.factory.peak',
 'spectrec.factory.spectral',
 'spectrec.losses',
 'spectrec.network',
 'spectrec.utils']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=5.4.1,<6.0.0',
 'matplotlib>=3.4.3,<4.0.0',
 'numpy>=1.21.2,<2.0.0',
 'tensorboard>=2.6.0,<3.0.0',
 'torch>=1.9.0,<2.0.0']

setup_kwargs = {
    'name': 'spectrec',
    'version': '0.1.0',
    'description': 'Lattice QCD spectral function reconstruction tools using neural networks',
    'long_description': None,
    'author': 'Sergio Chaves Garcia-Mascaraque',
    'author_email': 'sergiozteskate@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
