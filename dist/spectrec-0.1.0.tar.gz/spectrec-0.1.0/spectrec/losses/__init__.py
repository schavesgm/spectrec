# -- Import some classes
from .losses import MSELoss
from .losses import RMSELoss
